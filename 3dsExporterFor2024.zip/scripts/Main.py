# -*- coding:utf8 -*-
from PySide2 import QtCore
from PySide2 import QtWidgets
import qtmax
import os
import sys

# 确保系统默认编码支持UTF-8（用于中文路径）
if sys.platform == 'win32':
    if hasattr(sys, '_enablelegacywindowsfsencoding'):
        sys._enablelegacywindowsfsencoding = False

# 获取脚本所在目录
SCRIPT_DIR = os.path.dirname(__file__)

# 添加到 sys.path（优先级最高）
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

from pymxs import runtime as rt
from socketsOutput import socketsOutput


def _make_safe_filename(name: str) -> str:
    invalid_chars = '\\/:*?"<>|'
    safe = ''.join('_' if ch in invalid_chars else ch for ch in name)
    return safe or "export"


def _collect_export_nodes(parent_widget=None, ancestor_depth=0):
    """收集导出所需的节点列表及默认命名。"""
    selected_objs = [obj for obj in rt.selection]

    if not selected_objs:
        all_objects = rt.objects
        visible_objects = [obj for obj in all_objects if not obj.isHidden]
        if not visible_objects:
            QtWidgets.QMessageBox.warning(parent_widget, "警告", "场景中没有找到可导出的对象")
            return None, None
        return list(visible_objects), None

    def find_ancestor_by_depth(node, depth):
        chain = []
        current = node
        while current:
            chain.append(current)
            current = current.parent
        chain.reverse()  # 根节点在前
        target_index = min(max(depth, 0), len(chain) - 1)
        return chain[target_index]

    def collect_all_descendants(node, collected, collected_set):
        if node in collected_set:
            return
        collected.append(node)
        collected_set.add(node)
        for child in node.children:
            collect_all_descendants(child, collected, collected_set)

    root_nodes = []
    seen_roots = set()
    for obj in selected_objs:
        root = find_ancestor_by_depth(obj, ancestor_depth)
        if root not in seen_roots:
            root_nodes.append(root)
            seen_roots.add(root)

    all_nodes = []
    collected_set = set()
    for root in root_nodes:
        collect_all_descendants(root, all_nodes, collected_set)

    if not all_nodes:
        QtWidgets.QMessageBox.warning(parent_widget, "警告", "没有找到可导出的对象")
        return None, None

    export_name = root_nodes[0].name if root_nodes else None

    return all_nodes, export_name


def export_socket_bone(parent_widget=None, ancestor_depth=0):
    """导出Socket Bone（兼容常规物体）"""
    nodes, default_name = _collect_export_nodes(
        parent_widget=parent_widget,
        ancestor_depth=ancestor_depth,
    )
    if not nodes:
        return

    if default_name:
        default_name = _make_safe_filename(default_name)
    else:
        scene_name = str(rt.maxFileName)
        default_name = _make_safe_filename(scene_name) if scene_name else "export"

    file_path, _ = QtWidgets.QFileDialog.getSaveFileName(
        parent_widget,
        "保存FBX文件",
        f"{default_name}.fbx",
        "FBX Files (*.fbx)",
    )
    if not file_path:
        return

    try:
        socketsOutput([node.name for node in nodes], file_path)
        QtWidgets.QMessageBox.information(parent_widget, "成功", f"FBX文件已导出到:\n{file_path}")
    except Exception as e:
        QtWidgets.QMessageBox.critical(parent_widget, "错误", f"导出失败:\n{str(e)}")


class PyMaxDockWidget(QtWidgets.QDockWidget):
    def __init__(self, parent=None):
        super(PyMaxDockWidget, self).__init__(parent)
        self.setWindowFlags(QtCore.Qt.Tool)
        self.setWindowTitle('MaxExporter')
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        qtmax.DisableMaxAcceleratorsOnFocus(self, True)
        self._init_ui()

    def _init_ui(self):
        main_layout = QtWidgets.QVBoxLayout()

        depth_layout = QtWidgets.QHBoxLayout()
        depth_label = QtWidgets.QLabel("根层级:")
        depth_label.setToolTip("0 表示追溯到根节点；1 表示追溯到根节点的子节点；以此类推。")
        depth_layout.addWidget(depth_label)

        self.root_depth_spin = QtWidgets.QSpinBox()
        self.root_depth_spin.setRange(0, 10)
        self.root_depth_spin.setValue(0)
        self.root_depth_spin.setToolTip("控制向上追溯的层级，避免同根节点时全选整个场景。")
        depth_layout.addWidget(self.root_depth_spin)
        depth_layout.addStretch()

        main_layout.addLayout(depth_layout)

        select_btn = QtWidgets.QPushButton("选中父子级")
        select_btn.clicked.connect(self.select_hierarchy)
        main_layout.addWidget(select_btn)
        
        select_related_btn = QtWidgets.QPushButton("选中关联项")
        select_related_btn.clicked.connect(self.select_related)
        main_layout.addWidget(select_related_btn)

        select_group_btn = QtWidgets.QPushButton("全选组")
        select_group_btn.clicked.connect(self.select_group)
        main_layout.addWidget(select_group_btn)

        export_btn = QtWidgets.QPushButton("导出")
        export_btn.clicked.connect(self.export_selection)
        main_layout.addWidget(export_btn)

        widget = QtWidgets.QWidget()
        widget.setLayout(main_layout)
        self.setWidget(widget)
        self.setMinimumSize(260, 160)
        self.resize(320, 200)

    def select_hierarchy(self):
        nodes, _ = _collect_export_nodes(
            parent_widget=self,
            ancestor_depth=self.root_depth_spin.value(),
        )
        if not nodes:
            return
        rt.clearSelection()
        for node in nodes:
            rt.selectMore(node)

    def select_related(self):
        # 以句柄为唯一依据，避免串选；先扩展上下级（到组头或骨架连通），再选出被骨骼影响的网格
        current = [n for n in rt.selection]
        if not current:
            QtWidgets.QMessageBox.information(self, "提示", "请先选择一个节点")
            return

        def is_geometry(node):
            try:
                return rt.superClassOf(node) == rt.GeometryClass
            except Exception:
                return False

        def get_skin_modifier(node):
            try:
                for m in node.modifiers:
                    if rt.classOf(m) == rt.Skin:
                        return m
            except Exception:
                pass
            return None

        def iter_skin_bones(skin_mod):
            try:
                count = int(rt.skinOps.GetNumberBones(skin_mod))
            except Exception:
                count = 0
            for i in range(1, count + 1):
                try:
                    bn = rt.skinOps.GetBoneNode(skin_mod, i)
                except Exception:
                    bn = None
                if bn:
                    yield bn

        def gather_scene_skin_bones():
            bones = set()
            for obj in rt.objects:
                if not is_geometry(obj):
                    continue
                skin = get_skin_modifier(obj)
                if not skin:
                    continue
                for bn in iter_skin_bones(skin):
                    bones.add(bn)
            return bones

        def skin_has_bone_by_handle(skin_mod, bone_node):
            try:
                target_handle = int(bone_node.handle)
            except Exception:
                return False
            try:
                count = int(rt.skinOps.GetNumberBones(skin_mod))
            except Exception:
                count = 0
            for i in range(1, count + 1):
                try:
                    bn = rt.skinOps.GetBoneNode(skin_mod, i)
                except Exception:
                    bn = None
                if not bn:
                    continue
                try:
                    if int(bn.handle) == target_handle:
                        return True
                except Exception:
                    pass
            return False

        # 1) 计算组边界（若有组头则用组头内的网格作为查询范围）
        def find_group_head(node):
            cur = node
            while cur:
                try:
                    if rt.isGroupHead(cur):
                        return cur
                except Exception:
                    pass
                try:
                    h = rt.groupHead(cur)
                except Exception:
                    h = None
                if h:
                    return h
                try:
                    cur = cur.parent
                except Exception:
                    cur = None
            return None

        def collect_descendants(root):
            result = []
            if not root:
                return result
            stack = [root]
            visited = set()
            while stack:
                node = stack.pop()
                if node in visited:
                    continue
                visited.add(node)
                result.append(node)
                try:
                    for ch in node.children:
                        stack.append(ch)
                except Exception:
                    pass
            return result

        gh = find_group_head(current[0])
        group_nodes = collect_descendants(gh) if gh else None

        # 2) 选中集合拆分
        selected_meshes = [n for n in current if is_geometry(n) and get_skin_modifier(n)]
        selected_bones = [n for n in current if n not in selected_meshes]

        # 3) 初始骨骼集合
        initial_bones = []
        seen_b = set()
        # 来自已选网格
        for mesh in selected_meshes:
            skin = get_skin_modifier(mesh)
            if not skin:
                continue
            for bn in iter_skin_bones(skin):
                if bn not in seen_b:
                    initial_bones.append(bn)
                    seen_b.add(bn)
        # 叠加已选骨骼
        for bn in selected_bones:
            if bn not in seen_b:
                initial_bones.append(bn)
                seen_b.add(bn)

        if not initial_bones:
            QtWidgets.QMessageBox.information(self, "提示", "未能从选择中识别到骨骼或蒙皮网格")
            return

        # 4) 在“全场景被 Skin 引用的骨骼集合”中扩展父/子，形成连通骨架
        bone_pool = gather_scene_skin_bones()
        pool_set = set(bone_pool)
        expanded_bones = []
        visited = set()
        queue = [b for b in initial_bones if b in pool_set]
        while queue:
            cur = queue.pop(0)
            if cur in visited:
                continue
            visited.add(cur)
            expanded_bones.append(cur)
            try:
                p = cur.parent
            except Exception:
                p = None
            if p and p in pool_set and p not in visited:
                queue.append(p)
            try:
                for ch in cur.children:
                    if ch in pool_set and ch not in visited:
                        queue.append(ch)
            except Exception:
                pass

        if not expanded_bones:
            QtWidgets.QMessageBox.information(self, "提示", "未找到可扩展的骨骼层级")
            return

        # 5) 查找受这些骨骼影响的网格（句柄匹配）。若存在组头，则仅在组内网格查找；否则全场景
        candidate_nodes = group_nodes if group_nodes is not None else [obj for obj in rt.objects]
        related_meshes = []
        seen_mesh = set()
        for obj in candidate_nodes:
            if not is_geometry(obj):
                continue
            skin = get_skin_modifier(obj)
            if not skin:
                continue
            for b in expanded_bones:
                if skin_has_bone_by_handle(skin, b):
                    if obj not in seen_mesh:
                        related_meshes.append(obj)
                        seen_mesh.add(obj)
                    break

        # 6) 输出选择：扩展后的骨骼 + 关联网格
        rt.clearSelection()
        for b in expanded_bones:
            rt.selectMore(b)
        for m in related_meshes:
            rt.selectMore(m)

    def select_group(self):
        selected_nodes = [n for n in rt.selection]
        if not selected_nodes:
            QtWidgets.QMessageBox.information(self, "提示", "请先选择一个组内的节点或组头")
            return

        def find_group_head(node):
            cur = node
            while cur:
                try:
                    if rt.isGroupHead(cur):
                        return cur
                except Exception:
                    pass
                # direct groupHead if member
                try:
                    h = rt.groupHead(cur)
                except Exception:
                    h = None
                if h:
                    return h
                try:
                    cur = cur.parent
                except Exception:
                    cur = None
            return None

        group_heads = set()
        for n in selected_nodes:
            h = find_group_head(n)
            if h:
                group_heads.add(h)

        if not group_heads:
            QtWidgets.QMessageBox.information(self, "提示", "所选对象不在任何组内")
            return

        # 收集所有属于这些组头的成员（包含组头本身）
        result = set()
        for obj in rt.objects:
            # 同样向上查找是否属于这些组
            h2 = find_group_head(obj)
            if h2 and h2 in group_heads:
                result.add(obj)
        for h in group_heads:
            result.add(h)

        if not result:
            return

        rt.clearSelection()
        for node in result:
            rt.selectMore(node)

    def export_selection(self):
        export_socket_bone(
            parent_widget=self,
            ancestor_depth=self.root_depth_spin.value(),
        )


def main():
    main_window = qtmax.GetQMaxMainWindow()
    dock = PyMaxDockWidget(parent=main_window)
    dock.setFloating(True)
    dock.show()


if __name__ == '__main__':
    main()